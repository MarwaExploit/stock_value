# -*- coding: utf-8 -*-
##############################################################################
#
#    Copyright (C) 2015 Pexego All Rights Reserved
#    $Jesús Ventosinos Mayor <jesus@pexego.es>$
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as published
#    by the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
from openerp import models, fields, api
from openerp.addons.decimal_precision import decimal_precision as dp


class stock_picking(models.Model):

    _inherit = "stock.picking"

    amount_untaxed = fields.Float(
        compute='_amount_all', digits=dp.get_precision('Account'),
        string='Untaxed Amount', readonly=True, store=True)
    amount_tax = fields.Float(
        compute='_amount_all', digits=dp.get_precision('Account'),
        string='Taxes', readonly=True, store=True)
    amount_total = fields.Float(
        compute='_amount_all', digits=dp.get_precision('Account'),
        string='Total', readonly=True, store=True)
    amount_gross = fields.Float(
        compute='_amount_all', digits=dp.get_precision('Account'),
        string='amount gross', readonly=True, store=True)
    amount_discounted = fields.Float(
        compute='_amount_all', digits=dp.get_precision('Account'),
        string='amount discounted', readonly=True, store=True)
    external_note = fields.Text(
        ' External Notes')
    valued_picking = fields.Boolean(string="Print valued picking",
                                    help="If checked It will print valued "
                                    "picks for this customer")

    @api.multi
    @api.depends('move_lines.price_subtotal', 'partner_id')
    def _amount_all(self):
        self.amount_tax = sum(line.montant_tva for line in self.move_lines)
        self.amount_discounted=sum(line.montant_rem for line in self.move_lines)
        
        self.amount_untaxed = sum(line.price_subtotal for line in self.move_lines)+ self.amount_discounted
      
        self.amount_total = (sum(line.price_subtotal for line in self.move_lines)) + self.amount_tax 

class stock_move(models.Model):

    _inherit = "stock.move"

    price_subtotal = fields.Float(
        compute='_get_subtotal', string="Subtotal",
        digits=dp.get_precision('Account'), readonly=True)
    order_price_unit = fields.Float(
        compute='_get_subtotal', string="Price unit",
        digits=dp.get_precision('Product Price'), readonly=True,
        store=True)
    cost_subtotal = fields.Float(
        compute='_get_subtotal', string="Cost subtotal",
        digits=dp.get_precision('Account'), readonly=True,
        store=True)
    margin = fields.Float(
        compute='_get_subtotal', string="Margin",
        digits=dp.get_precision('Account'), readonly=True,
        store=True)
    percent_margin = fields.Float(
        compute='_get_subtotal', string="% margin",
        digits=dp.get_precision('Account'), readonly=True,
        store=True)

    @api.one
    @api.depends('product_id', 'product_uom_qty', 'procurement_id.sale_line_id')
    def _get_subtotal(self):
        for move in self:
  
            move.price_subtotal = (move.price_unit * move.product_uom_qty)- move.montant_rem
            
            
            
            
    def onchange_product_id(self, cr, uid, ids, product_id=False, loc_id=False, loc_dest_id=False, partner_id=False):
        res = super(stock_move, self).onchange_product_id(cr, uid, ids, product_id, loc_id, loc_dest_id, partner_id)
        product = self.pool.get('product.product').browse(cr, uid, product_id)
        p = self.pool.get('product.pricelist.item').browse(cr, uid, product_id)
        if product:
            res['value']['invoice_line_tax_id'] = product.taxes_id.ids
            res['value']['price_unit'] = product.list_price

            return res

    @api.one
    @api.depends('invoice_line_tax_id')
    def onchange_tax(self, product_id, loc_id=False, loc_dest_id=False, partner_id=False):

        unique_tax_ids = []
        if product_id:

            product_change_result = self.onchange_product_id(product_id, loc_id=loc_id, loc_dest_id=loc_dest_id,
                                                             partner_id=partner_id)
            if 'invoice_line_tax_id' in product_change_result.get('value', {}):
                unique_tax_ids = product_change_result['value']['invoice_line_tax_id']
        return {'value': {'invoice_line_tax_id': unique_tax_ids}}

    @api.one
    @api.depends('price_unit', 'invoice_line_tax_id', 'product_qty', 'product_id', 'discount')
    def _compute_tva(self):
        if self.invoice_line_tax_id.price_include:

            price = self.price_unit / (1 + self.invoice_line_tax_id.amount)
            rem_unit = price * ((self.discount or 0.0) / 100.0)
            ht = price - rem_unit
            self.ht = ht

            rem = price * ((self.discount or 0.0) / 100.0) * self.product_qty
            self.montant_rem = rem
            self.montant_tva = (ht * self.invoice_line_tax_id.amount) * self.product_qty

        else:

            rem_unit = self.price_unit * ((self.discount or 0.0) / 100.0)
            ht = self.price_unit - rem_unit
            self.ht = ht
            rem = self.price_unit * ((self.discount or 0.0) / 100.0) * self.product_qty
            self.montant_rem = rem
            self.montant_tva = (ht * self.invoice_line_tax_id.amount) * self.product_qty

    montant_tva = fields.Float(string='Mont TVA',  readonly=True,  compute='_compute_tva')
    montant_rem = fields.Float(string='Mont Remise', readonly=True, compute='_compute_tva')
    ht = fields.Float(string='Prix_Unit_HT',  readonly=True, compute='_compute_tva')
    
 

    @api.one
    @api.depends('price_unit', 'product_qty', 'invoice_line_tax_id', 'discount')
    def _price_total(self):
        self.price_total = self.price_unit * self.product_qty

    price_unit = fields.Float('Unit Price', digits=dp.get_precision('Product Price'))
    price_total = fields.Float(compute='_price_total', string='Prix Total', digits=dp.get_precision('Product Price'),
                               readonly=True)
    invoice_line_tax_id = fields.Many2many('account.tax', string='Taxes')
    discount = fields.Float(string='Discount (%)', digits=dp.get_precision('Discount'),
                            default=0.0)        
           

class StockPackOperation(models.Model):

    _inherit = 'stock.pack.operation'

    price_unit = fields.Float(
        compute='_get_subtotal', string="Price unit",
        digits=dp.get_precision('Product Price'), readonly=True)
    price_subtotal = fields.Float(
        compute='_get_subtotal', string="Subtotal",
        digits=dp.get_precision('Account'), readonly=True)

    @api.multi
    def _get_subtotal(self):
        for operation in self:
            subtotal = 0.0
            for link in operation.linked_move_operation_ids:
                move_id = link.move_id
                subtotal += move_id.price_subtotal * link.qty / move_id.product_uom_qty
            if operation.linked_move_operation_ids:
                operation.price_unit = subtotal / operation.product_qty
                operation.price_subtotal = subtotal
